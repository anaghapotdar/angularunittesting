
// describe('BillingService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [BillingService]
//     });
//   });

//   it('should be created', inject([BillingService], (service: BillingService) => {
//     expect(service).toBeTruthy();
//   }));
// });

import { TestBed, getTestBed, inject } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { HttpParams } from '@angular/common/http';

import { BillingService } from '../Services/billing.service';
import { User} from '../Models/pricingTemplate';

describe('BillingService', () => {
  let injector;
  let service: BillingService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BillingService]
    });

    injector = getTestBed();
    service = injector.get(BillingService);
    httpMock = injector.get(HttpTestingController);
  });

  describe('#getUsers', () => {
    it('should return an Observable<User[]>', () => {

      const dummyUsers: User[] = [
    {id:  1,
    login:  'Anagha',
    avatar_url:  '',
    events_url:  '',
    followers_url:  '',
    following_url:  '',
    gists_url: '',
    gravatar_id:  '',
    html_url:  '',
    organizations_url:  '',
    received_events_url: '',
    repos_url:  '',
    site_admin: false,
    starred_url:  '',
    subscriptions_url:  '',
    type:  '',
    url: ''}];

      service.getUsers().subscribe(users => {
        expect(users.length).toBe(1);
        expect(users).toEqual(dummyUsers);
      });

      const req = httpMock.expectOne(`${service.API_URL}/users`);
      expect(req.request.method).toBe('GET');
      req.flush(dummyUsers);
    });
  });


});
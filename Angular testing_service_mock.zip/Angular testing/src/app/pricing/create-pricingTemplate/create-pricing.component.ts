import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-create-pricing',
  templateUrl: './create-pricing.component.html',
  styleUrls: ['./create-pricing.component.css']
})
export class CreatePricingComponent implements OnInit {

  @Input() title:'Create Pricing';




  constructor() {
  }

  ngOnInit() {
  }

}

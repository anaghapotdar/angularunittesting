import { Component, OnInit } from "@angular/core";


@Component({
  selector: "app-serviceagreement",
  templateUrl: "./serviceagreement.component.html",
  styleUrls: ["./serviceagreement.component.css"]
})
export class ServiceAgreementComponent implements OnInit {
  data = [];
 title:'View Service Agreement';

  show: Boolean;

  constructor() {}

  ngOnInit() {
    this.show = true;
    
  }
}

import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import {ServiceAgreementRoutingModule  } from "./serviceagreement-routing.module";
import {ServiceAgreementComponent } from "./serviceagreement.component";

@NgModule({
  imports: [CommonModule, ServiceAgreementRoutingModule],
  declarations: [ServiceAgreementComponent]
})
export class ServiceAgreementModule {}

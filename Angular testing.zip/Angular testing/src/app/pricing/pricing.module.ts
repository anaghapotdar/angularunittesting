import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";

import {PricingRoutingModule} from './pricing-routing.module';

import {CreatePricingComponent } from "./create-pricingtemplate/create-pricing.component";
import {ViewPricingComponent } from "./view-pricingtemplate/view-pricing.component";

@NgModule({
    imports:[
        CommonModule,
        PricingRoutingModule
    ],
    declarations:[CreatePricingComponent,ViewPricingComponent ]

})

export class PricingModule{}
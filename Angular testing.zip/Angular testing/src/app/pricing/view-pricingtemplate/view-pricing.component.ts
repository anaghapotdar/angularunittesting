import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-view-pricing',
  templateUrl: './view-pricing.component.html',
  styleUrls: ['./view-pricing.component.css']
})
export class ViewPricingComponent implements OnInit {

  @Input() title:'View Pricing';




  constructor() {
  }

  ngOnInit() {
  }

}

import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";


import {CreatePricingComponent} from './create-pricingtemplate/create-pricing.component';
import {ViewPricingComponent} from './view-pricingtemplate/view-pricing.component';

const routes:Routes=[
    {path:'',component:ViewPricingComponent},
    {path:'create',component:CreatePricingComponent},
    {path:'View',component:ViewPricingComponent}
]


@NgModule({
    imports:[RouterModule.forChild(routes)],
    exports:[RouterModule]
})

export class PricingRoutingModule{}
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { ServiceAgreementComponent} from './serviceagreement.component'


const routes: Routes = [
    { path: "", component: ServiceAgreementComponent},

];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(routes)]
})
export class ServiceAgreementRoutingModule { }